
### Front-End Unit Testing of JQuery Web Application

This is an application that calculates the cgpa of a student in a typical Nigeria University. The application illustrates how to use jasmine-jquery, jasmine, gulp, browserify and karma for the unit testing.

**Usage**

- Clone the repository git clone https://github.com/elahsoft/Front-End-Unit-Testing-JQuery-Web-Application.gi
t
- Run npm install to install all dependencies.
- To run test, run npm run specRunner to see the the specRunner.html;and npm run karmaTest.

**Technologies and Services**

The application is a node based application which uses JQuery. 
Other Technologies were employed to ensure the quality of the code include:
- Gulp
- Jasmine JQuery
- Karma

**Contributions**
See the tutorial assignment section.

